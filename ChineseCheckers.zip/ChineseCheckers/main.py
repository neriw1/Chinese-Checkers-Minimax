from View import View

if __name__ == '__main__':
    View()
